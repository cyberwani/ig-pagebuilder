/**
 * @version    $Id$
 * @package    IGPGBLDR
 * @author     InnoGears Team <support@innogears.com>
 * @copyright  Copyright (C) 2012 InnoGears.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.innogears.com
 * Technical Support: Feedback - http://www.innogears.com/contact-us/get-support.html
 */
( function ($)
{
	"use strict";

	$.IGTable	= $.IGTable || {};
    $.PbDoing = $.PbDoing || {};

	$.IGTable = function () {};

	$.IGTable.prototype = {
        init: function(active_shortcode){
            // get current th/td
            var parent_wrap = active_shortcode.find(".jsn-item-content").first().parent('.jsn-item').parent();
            this.updateColWidth(active_shortcode, parent_wrap);
            this.spanProcess(parent_wrap);
        },
        // update column width
        updateColWidth: function (active_shortcode, parent_wrap) {
            var cell_content = window.parent.jQuery.noConflict()( '#jsn_view_modal').contents().find('#ig_share_data').text();
            active_shortcode.find(".jsn-item-content").first().html($.HandleElement.sliceContent(cell_content));
            // get updated width value
            var merge_data = window.parent.jQuery.noConflict()( '#jsn_view_modal').contents().find('#ig_merge_data');
            // update width
            parent_wrap.css('width', (merge_data.text() == '%') ? '' : merge_data.text());
            // reset #ig_merge_data value
            merge_data.text('');
        },
        // extract colspan, rowspan of cell. then update table structure
        spanProcess: function(parent_wrap){
            var self = this;
            var data = {};
            var extract_data = window.parent.jQuery.noConflict()( '#jsn_view_modal').contents().find('#ig_extract_data');

            // extract data, sample data: param-rowspan:2#param-colspan:2#
            $.each(extract_data.text().split('#'), function(key, value){
                if(value){
                    value = value.split(':');
                    var attr_value = parseInt(value[1]);
                    var attr_name = value[0].replace('param-', '');
                    data[attr_name] = attr_value;
                }
            })

            // get info
            var table = parent_wrap.parents("#table_content");
            var parent_row = parent_wrap.parent("tr");
            var self_index = parseInt(parent_wrap.attr('data-cell-index'));
            var self_content = parent_wrap.find(".jsn-item-content").first();
            var self_textarea = parent_wrap.find("textarea").first();
            var row_idx = parent_row.index();
            var child = (row_idx == 0) ? 'th' : 'td';
            var col_idx = parent_row.find(child).index(parent_wrap);

            // validate if rowspan/colspan exceed the limit
            data['rowspan'] = ((row_idx + data['rowspan']) > (table.find('tr').length - 1)) ? table.find('tr').length - 1 - row_idx : data['rowspan'];
            data['colspan'] = ((col_idx + data['colspan']) > (parent_row.children(child).length - 1)) ? parent_row.children(child).length - 1 - col_idx : data['colspan'];

            // update colspan, rowspan
            $.each(data, function(attr_name, attr_value){
                // update attributes
                parent_wrap.attr(attr_name, attr_value);
                // update textarea
                var regexp = new RegExp(attr_name+'="[0-9]"', "g");
                $(self_textarea).text(self_textarea.val().replace(regexp,attr_name+'="'+attr_value+'"'));
            })
            // do nothing
            if(data['rowspan'] == 1 && data['colspan'] == 1) return;

            // get related rows
            var related_rows;
            if(data['rowspan'] > 1){
                if(data['colspan'] > 1)
                    related_rows = table.find('tr').slice(row_idx, row_idx + data['rowspan']);
                else
                    related_rows = table.find('tr').slice(row_idx + 1, row_idx + data['rowspan']);
            }else
                related_rows = parent_row;

            // get content of cells & add Remove flag
            $(related_rows).each(function(i){
                var row_idx_ = table.find("tr").index($(this));
                var child_ = (row_idx_ == 0) ? 'th' : 'td';
                var related_columns = $(this).find(child_+'[data-cell-index="'+self_index+'"]');
                if(data['colspan'] > 1){
                    if(data['rowspan'] > 1 && i > 0){
                        self.cellProcess(related_columns, self_content);
                    }
                    related_columns = $(this).find(child_).filter(function(){return  parseInt($(this).attr("data-cell-index")) > self_index && parseInt($(this).attr("data-cell-index")) < (self_index + data['colspan'])});
                }
                $(related_columns).each(function(){
                    self.cellProcess($(this), self_content);
                })
            })
            // update Textarea
            $(self_textarea).text(self_textarea.val().replace(/].*\[/,"]"+(self_content.html())+"["));
            // remove cells have Remove flag
            table.find('.ig-remove-cell').each(function(){
                $(this).remove();
            })
            // reset #ig_extract_data value
            extract_data.text('');
            self.reindexTable();
            self.cleanDeleteBtn();
        },
        // get cell content and add 'ig-remove-cell' class
        cellProcess:function(this_, self_content){
            var cell_content = this_.find(".jsn-item-content").first().html();
            if(cell_content != "" && cell_content != null)
                self_content.html(self_content.html()+'<br>'+cell_content);
            this_.addClass('ig-remove-cell');
        },
        // add texteare of tr_start, tr_end to row of table
        appendTextarea : function(row, first_child){
            if(first_child == null)
                first_child = row.find('td').first();
            first_child.before(tr_start);
            row.append(tr_end);
        },
        // clean table: remove rows which only have delete button
        cleanDeleteBtn:function(){
            $("#table_content tr").each(function(row_idx){
                var child = (row_idx==0) ? 'th' : 'td';
                // if empty, remove delete button, not remove whole row
                if($(this).find(child).length == 1)
                    $(this).find('.ig-delete-column-td').empty();
            })
        },
        // reindex cell in table
        reindexTable:function(){
            // reset index
            $("#table_content tr").each(function(row_idx){
                var child = (row_idx==0) ? 'th' : 'td';
                $(this).find(child).each(function(){
                    $(this).removeAttr('data-cell-index');
                })
            })
            $("#table_content tr").each(function(row_idx){
                var child = (row_idx==0) ? 'th' : 'td';
                var row = $(this);
                $(this).find(child).each(function(cell_idx){
                    var colspan = parseInt($(this).attr("colspan"));
                    var rowspan = parseInt($(this).attr("rowspan"));
                    if($(this).attr('data-cell-index') == null){
                        if(cell_idx == 0)
                            $(this).attr('data-cell-index', 0);
                        else{
                            var prev_cell = row.find(child).eq(cell_idx - 1);
                            var prev_cell_colspan = (prev_cell.attr('colspan') != null) ? prev_cell.attr('colspan') : 1;
                            $(this).attr('data-cell-index', parseInt(prev_cell.attr('data-cell-index')) + parseInt(prev_cell_colspan));
                        }
                    }
                    var self_index = $(this).attr('data-cell-index');
                    // update index for related cell
                    if(rowspan > 1){
                        var related_rows = $("#table_content").find('tr').slice(row_idx + 1, row_idx + rowspan);
                        $(related_rows).each(function(){
                            var row_idx_ = $("#table_content").find("tr").index($(this));
                            var child_ = (row_idx_ == 0) ? 'th' : 'td';
                            var related_cell = $(this).find(child_+':eq('+cell_idx+')');
                            related_cell.attr('data-cell-index', parseInt(self_index) + colspan);
                        })
                    }

                })
            })
            $.PbDoing.addRowCol = 0;
        },

        preDeleteCol:function(idx_delete){
            $("#table_content tr").each(function(row_idx){
                var child = (row_idx==0) ? 'th' : 'td';
                $(this).find(child).each(function(){
                    var colspan = parseInt($(this).attr("colspan"));
                    var rowspan = parseInt($(this).attr("rowspan"));
                    var cell_idx = parseInt($(this).attr("data-cell-index"));
                    if(colspan > 1){
                        if(cell_idx <= idx_delete && idx_delete <= (cell_idx + colspan -1)){
                            $(this).attr("colspan", colspan - 1);
                            // update Textarea
                            var self_textarea = $(this).find("textarea").first();
                            var regexp = new RegExp('colspan="[0-9]"', "g");
                            $(self_textarea).text(self_textarea.val().replace(regexp,'colspan="'+ (colspan - 1)+'"'));
                            if(cell_idx == idx_delete){
                                $(this).attr('data-cell-index', parseInt($(this).attr('data-cell-index')) + 1);
                            }
                        }
                    }
                })
            })
        },
        preDeleteRow:function(idx_delete){
            $("#table_content tr").each(function(row_idx){
                var child = (row_idx==0) ? 'th' : 'td';
                $(this).find(child).each(function(cell_idx){
                    var rowspan = parseInt($(this).attr("rowspan"));
                    if(rowspan > 1){
                        if(row_idx <= idx_delete && idx_delete <= (row_idx + rowspan -1)){
                            $(this).attr("rowspan", parseInt(rowspan) - 1);
                            // update Textarea content
                            var self_textarea = $(this).find("textarea").first();
                            var regexp = new RegExp('rowspan="[0-9]"', "g");
                            $(self_textarea).text(self_textarea.val().replace(regexp,'rowspan="'+ (parseInt(rowspan) - 1)+'"'));

                            if(row_idx == idx_delete){
                                // insert a cell in same index to next row
                                var below_cell = $("#table_content tr").eq(row_idx + 1).find("td").eq(cell_idx);
                                below_cell.before($("<div />").append($(this).clone()).html());
                            }
                        }
                    }
                })
            })
        },
        // Handle Delete row, column
        deleteColRow:function(item, type, Ig_Translate){
            var self = this;
            switch (type) {
                    case 'column':
                        var idx_delete = parseInt(item.parents('td').attr('data-cell-index'));
                        if($("#table_content tr").last().find('td').length == 1){
                            alert(Ig_Translate.table1);
                            return true;
                        }
                        self.preDeleteCol(idx_delete);
                        $("#table_content tr").each(function(i){
                            var child = (i==0) ? 'th' : 'td';
                            var cell = $(this).find(child+'[data-cell-index="'+idx_delete+'"]');
                            cell.remove();
                        })
                        $("#bottom_row tr").each(function(){
                            var cell = $(this).find('td[data-cell-index="'+idx_delete+'"]');
                            cell.remove();
                        })
                        self.reindexTable();
                        break;
                    case 'row':
                        var row_idx = item.parents('tr').index();
                        if($("#table_content tr").length == 3){
                            alert(Ig_Translate.table2);
                            return true;
                        }
                        self.preDeleteRow(row_idx);
                        $("#table_content tr").eq(row_idx).remove();
                        $("#right_column tr").eq(row_idx).remove();
                        self.reindexTable();
                        break;
                }
            return true;

        },
        // Handle Add row,column
        addRowCol:function(){
            var self = this;
            // Handle "Add Row", "Add Column" button
            $("#modalOptions").delegate(".table_action", "click", function(e){
                e.preventDefault();

                if($.PbDoing.addRowCol)
                    return;
                $.PbDoing.addRowCol = 1;

                var data_target = $(this).attr('data-target');
                var $shortcode = 'ig_item_table';
                if($("#tmpl-"+$shortcode).length == 0){
                    $.HandleElement.getShortcodeTpl($shortcode, 'element', function(data){
                        $('body').append(data);
                        self.addRowColFinish(data_target, $shortcode, self);
                    })
                }
                else{
                    self.addRowColFinish(data_target, $shortcode, self);
                }
            });
        },
        // do action after have tmpl-ig_item_table HTML structure
        addRowColFinish:function(data_target, $shortcode, self){
            if(data_target == "table_row"){
                // Add New Row
                var row = [];
                row.push('<tr>');
                var countColumn = $("#table_content tr").last().find('td').length;

                for(var i = 0 ; i < countColumn; i++){
                    row.push('<td>' + $("#tmpl-"+$shortcode).html() + '</td>');
                }
                // add right delete row button
                row.push($("<div />").append($("#table_content tr").eq(1).find('td').last().clone()).html());

                row.push('</tr>');
                $("#table_content tr").last().before(row.join(""));
                // append Textarea To Added Row
                self.appendTextarea($("#table_content").find("tr").eq($("#table_content").find("tr").length - 2), null, tr_start, tr_end);
            }
            else if(data_target == "table_column"){
                // Add New Column
                $("#table_content tr").each(function(i){
                    var cell_wrapper = (i==0) ? 'th' : 'td';
                    var content = $("#tmpl-"+$shortcode).html();
                    if(i+1 == $("#table_content tr").length)
                        content = $("#table_content tr").last().find('td').first().html();
                    $(this).find(cell_wrapper).last().before('<'+cell_wrapper+'>' + content + '</'+cell_wrapper+'>');
                })
            }
            self.reindexTable();
        }
    }

    var tr_start = "<textarea class='hidden' data-sc-info='shortcode_content' name='shortcode_content[]'>[ig_item_table tagname='tr_start' ][/ig_item_table]</textarea>";
    var tr_end = "<textarea class='hidden' data-sc-info='shortcode_content' name='shortcode_content[]'>[ig_item_table tagname='tr_end' ][/ig_item_table]</textarea>";
    $(document).ready(function(){
        var colspan = $("#param-colspan").val();
        var rowspan = $("#param-rowspan").val();
        if(colspan > 1 || rowspan > 1){
            // disable change span of changed cell
            $("#param-colspan").attr('disabled','disabled');
            $("#param-rowspan").attr('disabled','disabled');
        }
        var Ig_Table = new $.IGTable();

        // append Textarea To Rows
        $("#table_content").find("tr").slice(0, $("#table_content").find("tr").length - 1).each(function(i){
            var first_child = (i==0) ? $(this).find('th').first() : $(this).find('td').first();
            Ig_Table.appendTextarea($(this), first_child);
        })

        Ig_Table.addRowCol();
        Ig_Table.reindexTable();
    })

})(jQuery);